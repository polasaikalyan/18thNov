﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using StudentRepositorySystem.Models;

namespace StudentRepositorySystem.Controllers
{
    public class LoginController : Controller
    {
        private masterEntities db = new masterEntities();

        public ActionResult MainPage()
        {
            return View();
        }

        public ActionResult StudentRegister()
        {            
            return View();
        }

        [HttpPost]
        public ActionResult StudentRegister(StudentDetail student)
        {
            if (ModelState.IsValid)
            {
                db.StudentDetails.Add(student);
                db.SaveChanges();
                return Json(new { msg = "Successfully Registered", data = student.studentid }, JsonRequestBehavior.AllowGet);
                //return RedirectToAction("StudentLogin");
            }
            return View();
        }

        public ActionResult StudentLogin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult StudentLogin(int? studentid, string password)
        {
            var isStudentIdExists = db.StudentDetails.Where(a => a.studentid == studentid).SingleOrDefault();
            if (isStudentIdExists != null)
            {
                if (isStudentIdExists.password == password)
                {
                    Session["usertype"] = "student";
                    Session["studentid"] = isStudentIdExists.studentid;
                    Session["username"] = isStudentIdExists.studentname;
                    Session["imagepath"] = "~/Images/NoImage.jpg";
                    if (isStudentIdExists.photo != null)
                    {
                        Session["imagepath"] = "~/Images/" + isStudentIdExists.photo;
                    }
                    return RedirectToAction("DashBoard", "Student");
                }
                else { ModelState.AddModelError("password", "password not matched"); }
            }
            else { ModelState.AddModelError("studentid", "Id not exists"); }
            return View();
        }

        public ActionResult AdminLogin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AdminLogin(AdminLoginDetail admin)
        {
            var isAdminIdExists = db.AdminLoginDetails.Where(a => a.adminid == admin.adminid).SingleOrDefault();
            if (isAdminIdExists != null)
            {
                if (isAdminIdExists.adminpassword == admin.adminpassword)
                {
                    Session["usertype"] = "admin";
                    Session["studentid"] = isAdminIdExists.adminid;
                    return RedirectToAction("Dashbord", "Admin");
                }
                else { ModelState.AddModelError("adminpassword", "password not matched"); }
            }
            else { ModelState.AddModelError("adminid", "Id not exists"); }
            return View(admin);
        }

        [HttpPost]
        public JsonResult IsAlreadySigned(string email)
        {
            return Json(IsEmailAvailable(email));
        }

        public bool IsEmailAvailable(string email)
        {
            bool status = true;
            var IsEmailExists = db.StudentDetails.Where(a => a.email.ToUpper() == email.ToUpper()).FirstOrDefault();
            if (IsEmailExists != null)
            {
                status = false;
                return status;
            }
            return status;
        }
        public ActionResult ForgotIdorPassword()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ForgotIdorPassword(string email)
        {
            try
            {
                var res = db.StudentDetails.Where(a => a.email.ToUpper() == email.ToUpper()).FirstOrDefault();
                if (res == null)
                {
                    return Json(new { status = "failure", msg = "Can't Find Email in DB Please Enter Registered Email" }, JsonRequestBehavior.AllowGet);
                }

                string email1 = "rajashekar.karnati@capgemini.com";
                string password = "Qwerty@574";
                //string email1 = "rkarnati5@gmail.com";
                //string password = "yadagiri";

                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient("smtp.outlook.com");
                //SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

                mail.From = new MailAddress(email1, "Admin");
                mail.To.Add(email);
                mail.Subject = "Don't Forget Password";

                string body = "Your Id : " + res.studentid + "\n";
                body += "Your Password : " + res.password;
                mail.Body = body;
                mail.IsBodyHtml = true;
                //SmtpServer.UseDefaultCredentials = false;
                SmtpServer.Port = 25;
                SmtpServer.Credentials = new System.Net.NetworkCredential(email1, password);
                SmtpServer.EnableSsl = true;
                SmtpServer.Send(mail);
                //var body = "<p>Email From: {0} ({1})</p><p>Message:</p><p>{2}</p>";
                //var message = new MailMessage();
                //message.To.Add(new MailAddress(email));  // replace with valid value 
                //message.From = new MailAddress("rkarnati5@gmail.com");  // replace with valid value
                //message.Subject = "Your email subject";
                //message.Body = string.Format(body, "SRS", "kamesh.n@capgemini.com", "Dont Forget Password", "rajashekarkarnati123@gmail.com");
                //message.IsBodyHtml = true;


                //using (var smtp = new SmtpClient())
                //{
                //    var credential = new NetworkCredential
                //    {
                //        //UserName = "kamesh.n@capgemini.com",  // replace with valid value
                //        //Password = "Manjula@1a"  // replace with valid value

                //        UserName = "rkarnati5@gmail.com",  // replace with valid value
                //        Password = "yadagiri"  // replace with valid value
                //    };

                //    smtp.Credentials = credential;
                //    smtp.Host = "smtp.gmail.com";
                //    smtp.Port = 587;
                //    smtp.EnableSsl = true;
                //    await smtp.SendMailAsync(message);
                return Json(new { status = "success" }, JsonRequestBehavior.AllowGet);
                //    //return RedirectToAction("Sent");
                //}
            }
            catch (Exception e)
            {
                return Json(new { status = "failure", msg = e.Message.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult Logout()
        {
            Session.Clear();
            //return Content("<script>var backlen = history.length;history.go(-backlen);window.location.href='MainPage'</script>");
            //function ClearHistory()
            //{
            //    var backlen = history.length;
            //    history.go(-backlen);
            //    window.location.href = loggedOutPageUrl
            //}
            return RedirectToAction("MainPage");
        }
    }
}