﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using StudentRepositorySystem.Models;

namespace StudentRepositorySystem.Controllers
{
    public class JobsController : Controller
    {
        private masterEntities db = new masterEntities();

        // GET: Jobs
        public ActionResult DashBoard()
        {
            Session["usertype"] = "jobs";
            int jobsCount = db.Jobs.Count();
            ViewBag.jobsCount = jobsCount;
            return View();
        }

        public ActionResult ApplyJobs()
        {
            //var jobs = db.Jobs.ToList();
            return View();
        }

        [HttpGet]
        public ActionResult GetJobs()
        {
            var jobs = (from a in db.Jobs select new { jobid = a.jobid, jobtitle = a.jobtitle, companytitle = a.companytitle, jobdescription = a.jobdescription, createdon = a.createddate }).ToList();
            return Json(new { data = jobs }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult jobForm(int? id)
        {
            var job = db.Jobs.Find(id);
            return View(job);
        }

        public JsonResult GetDetailsByID(int? id)
        {
            var studentdetails = db.StudentDetails.Find(id);
            if (studentdetails != null)
            {
                //return Json(new { data=studentdetails }, JsonRequestBehavior.AllowGet);
                return Json(new { status = "success", studentname = studentdetails.studentname, age = studentdetails.age, address = studentdetails.address, mobileno = studentdetails.mobileno, dob = studentdetails.dob }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { status = "error", msg = "Id Not Found" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveJobApplyDetails()
        {
            if (System.Web.HttpContext.Current.Request.Files.Count > 0)
            {
                int id = Convert.ToInt32(System.Web.HttpContext.Current.Request["id"]);
                int jobid = Convert.ToInt32(System.Web.HttpContext.Current.Request["jobid"]);
                var IsAlreadyApplied = db.JobsApplieds.Where(a => a.studentid == id && a.jobid == jobid).ToList();
                if (IsAlreadyApplied.Count == 0)
                {
                    try
                    {
                        var pic = System.Web.HttpContext.Current.Request.Files["resume"];
                        HttpPostedFileBase filebase = new HttpPostedFileWrapper(pic);
                        var fileName = Path.GetFileName(filebase.FileName);
                        string ext = Path.GetExtension(fileName);
                        fileName = id.ToString()+ "_" + DateTime.Now.ToString("MM_dd_yyyy_hh_mm_ss") + ext;
                        var path = Path.Combine(Server.MapPath("~/Images/Resume/"), fileName);
                        filebase.SaveAs(path);
                        JobsApplied newjob = new JobsApplied()
                        {
                            jobid = jobid,
                            studentid = id,
                            applieddate = DateTime.Now.Date,
                            resume = fileName
                        };
                        db.JobsApplieds.Add(newjob);
                        db.SaveChanges();
                        return Json(new { status = "success" }, JsonRequestBehavior.AllowGet);
                    }
                    catch (Exception e)
                    {
                        return Json(new { status = "failed", error = e.Message.ToString() }, JsonRequestBehavior.AllowGet);
                    }
                }
                else
                {
                    return Json(new { status = "failed", error = "This Job is Already applied by this id" }, JsonRequestBehavior.AllowGet);
                }
            }
            else
            {
                return Json(new { status = "failed", error = "Something Went Wrong" }, JsonRequestBehavior.AllowGet);
            }
        }

        public bool isAuthorized()
        {
            bool auth = false;
            if (Session["usertype"].ToString() == "jobs")
            {
                auth = true;
            }
            return auth;
        }
    }
}